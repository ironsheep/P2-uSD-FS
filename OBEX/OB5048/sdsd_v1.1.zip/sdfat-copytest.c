
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <sys/time.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>


enum {
//	_xinfreq = 20_000_000,
	_xtlfreq = 20_000_000,
	_clkfreq = 200_000_000,

	DOWNLOAD_BAUD = 230_400,
	DEBUG_BAUD = DOWNLOAD_BAUD,

	HEAPSIZE = 8800,

//
// Prop2 boot pins, set in the Prop2 ROM
//
    MISO_EVAL = 58, MOSI_EVAL, CS_EVAL, CLK_EVAL,

//
// Roger Loh's 4-bit add-on board
//
    BASE_PIN_RL = 16,
    DAT0_RL     = BASE_PIN_RL+0,    // MISO, DO
    DAT1_RL     = BASE_PIN_RL+1,
    DAT2_RL     = BASE_PIN_RL+2,
    DAT3_RL     = BASE_PIN_RL+3,    // CS
    CMD_RL      = BASE_PIN_RL+4,    // MOSI, DI
    CLK_RL      = BASE_PIN_RL+5,    // SCLK
    LED_RL      = BASE_PIN_RL+6,    // output to red LED
    PWR_RL      = BASE_PIN_RL+7,    // Card-Detect input, and power switch, and green LED

    CS_RL       = DAT3_RL,
    MOSI_RL     = CMD_RL,
    MISO_RL     = DAT0_RL,

//
// My hand wired full sized 4-bit SD slot
//
    BASE_PIN_EH = 40,
    CMD_EH      = BASE_PIN_EH+2,    // MOSI, DI
    CLK_EH      = BASE_PIN_EH+3,    // SCLK
    DAT0_EH     = BASE_PIN_EH+4,    // MISO, DO
    DAT1_EH     = BASE_PIN_EH+5,
    DAT2_EH     = BASE_PIN_EH+6,
    DAT3_EH     = BASE_PIN_EH+7,    // CS

    CS_EH       = DAT3_EH,
    MOSI_EH     = CMD_EH,
    MISO_EH     = DAT0_EH,

	MAX_BUFFER_SIZE = (100 * 1024)
};

static int  mounted = 0;
static int32_t  xoro32state;


static void  randfill( uint32_t *addr, size_t size )
{
    int32_t  state = xoro32state;
    size >>= 2;

    __asm volatile {    // "volatile" enforces unoptimised use of FCACHE
		wrfast	#0, addr
		rep	@.rend, size
		xoro32	state
		mov	pb, 0-0
		wflong	pb
.rend
    }
    xoro32state = state;
}


static size_t  randcmp( const uint32_t *addr, size_t size )
{
    int32_t  state = xoro32state;
    size_t  pass = size >> 2;

    __asm volatile {    // "volatile" enforces unoptimised use of FCACHE
		rdfast	#0, addr
.loop
		rflong	pb
		xoro32	state
		cmp	pb, 0-0  wz
	if_z	djnz	pass, #.loop
    }
    xoro32state = state;

    return  size - (pass << 2);
}


void  memfill( void *buf, uint32_t value, size_t longs )
{
    __asm volatile {    // "volatile" enforces unoptimised use of FCACHE
		mov	patch, value
		sets	patch, #0b0011_11111    // replace with conditional AUGD opcode
		ror	patch, #9    // AUGD instruction orientation
		setd	patch+1, value    // fill out least 9 bits of WRLONG immediate value

		sub	longs, #1   wcz
	if_a	setq	longs    // fingers crossed this is applied to the WRLONG
//	if_ae	alti	value, #0b101_100_100    // substitute the whole AUGD
patch	if_ae	wrlong	##-1, buf
    }
}


void  memclear( void *buf, size_t longs )
{
    __asm {
		sub	longs, #1   wcz
	if_a	setq	longs
	if_ae	wrlong	#0, buf
    }
}


int  nullcheck( void *buf, size_t longs )
{
    __asm volatile {    // "volatile" enforces unoptimised use of FCACHE
		rdfast	#0, buf
		modcz	0xff   wz
		rep	@.rend, longs
	if_z	rflong	pb   wz
.rend
		wrz	longs
    }
    return longs;
}


static size_t  fgetsize( const char *filename )
{
    struct stat  st;

    errno = 0;
    if(stat(filename, &st))
        exit(1);
    return  st.st_size;  // filesize in bytes
}




static void  mountall( void )
{
    typedef struct __using("blkdrvr/sdsd.cc") drv_t;
//    typedef struct __using("blkdrvr/sdmm.cc") drv_t;
//    typedef struct __using("blkdrvr/sdmm_bashed.cc") drv_t;
    FILE *handle;

    umount("/sd1");
    umount("/sd2");

    drv_t *DRV1 = _gc_alloc_managed(sizeof(drv_t));
    drv_t *DRV2 = _gc_alloc_managed(sizeof(drv_t));

    _seterror(0);
    handle = DRV1->_sdsd_open(CLK_RL, CMD_RL, DAT0_RL, PWR_RL, LED_RL);
//    handle = DRV1->_sdmm_open(CLK_EVAL, CS_EVAL, MOSI_EVAL, MISO_EVAL);
    if( !handle )  {
        printf(" /sd1 open failed!   errno = %d: %s\n", errno, strerror(errno));
        _gc_free(DRV1);
        _gc_free(DRV2);
        exit(1);
    }
    printf(" /sd1 handle = %x\n", handle);
    mount("/sd1", _vfs_open_fat_handle(handle));

    _seterror(0);
    handle = DRV2->_sdsd_open(CLK_EH, CMD_EH, DAT0_EH, -1, -1);
//    handle = DRV2->_sdmm_open(CLK_RL, CS_RL, MOSI_RL, MISO_RL);
    if( !handle )  {
        printf(" /sd2 open failed!   errno = %d: %s\n", errno, strerror(errno));
        _gc_free(DRV1);
        _gc_free(DRV2);
        exit(1);
    }
    printf(" /sd2 handle = %x\n", handle);
    mount("/sd2", _vfs_open_fat_handle(handle));

    mounted = 1;
}



static void  rmfile( const char *filename )
{
    if(!mounted)
        mountall();

    printf("  deleting file %s ...", filename);
    errno = 0;
    remove(filename);  // ignore any errors
    perror("  deleted");
}



static void  writefile( const char *filename, size_t filesize )
{
    FILE  *fh;
    size_t  bufsize, count = 0;
    uint32_t  ticks, ticke, msecs = 0, onesecond, *data;

    if(!mounted)
        mountall();

    if(filesize / MAX_BUFFER_SIZE)  bufsize = MAX_BUFFER_SIZE;
    else  bufsize = filesize;

    if(data = __builtin_alloca(bufsize))    // auto-frees upon return
        printf("write file %s, buffer addr = 0x%x, size = %d\n", filename, data, bufsize);
    else {
        printf("malloc() failed!\n");
        exit(1);
    }

    onesecond = _clockfreq();
    ticks = _cnt();

    errno = 0;
    fh = fopen(filename, "wb");
    if(!fh) {
        perror("fopen() for writing failed");
        exit(1);
    }

    do {
        randfill(data, bufsize);
        if(fwrite(data, bufsize, 1, fh))  count += bufsize;
        else  exit(1);
        ticke = _cnt();
        while(ticke - ticks >= onesecond)  {
            ticks += onesecond;
            msecs += 1000;
        }
    } while(count < filesize);

    fclose(fh);
    ticke = _cnt();
    msecs += _muldiv64(ticke - ticks, 1000, _clockfreq());  // ticks to milliseconds
    printf("Written %d of %d bytes at %d kB/s\n", count, filesize,
        (_muldiv64(count, 1000, msecs) + 512) >> 10);

}



static void  copyfile( const char *filename1, const char *filename2 )
{
    FILE  *fh1, *fh2;
    size_t  filesize, bufsize, count = 0;
    uint32_t  ticks, ticke, msecs = 0, onesecond, *data;

    if(!mounted)
        mountall();

    filesize = fgetsize(filename1);
    printf("copy file length = %d\n", filesize);

    if(filesize / MAX_BUFFER_SIZE)  bufsize = MAX_BUFFER_SIZE;
    else  bufsize = filesize;

    if(data = __builtin_alloca(bufsize))    // auto-frees upon return
        printf("copy buffer addr = 0x%x, size = %d\n", data, bufsize);
    else {
        printf("malloc() failed!\n");
        exit(1);
    }
    memset(data, 0, bufsize);  // erase any echoes

    onesecond = _clockfreq();
    ticks = _cnt();

    errno = 0;
    fh1 = fopen(filename1, "rb");
    if(!fh1) {
        perror("fopen() for reading failed");
        exit(1);
    }

    fh2 = fopen(filename2, "wb");
    if(!fh2) {
        printf("fopen() for writing failed\n");
        exit(1);
    }

    do {
        if(!fread(data, bufsize, 1, fh1))  exit(1);
        ticke = _cnt();
        while(ticke - ticks >= onesecond)  {
            ticks += onesecond;
            msecs += 1000;
        }
        if(fwrite(data, bufsize, 1, fh2))  count += bufsize;
        else  exit(1);
        ticke = _cnt();
        while(ticke - ticks >= onesecond)  {
            ticks += onesecond;
            msecs += 1000;
        }
    } while(count < filesize);

    fclose(fh1);
    fclose(fh2);
    ticke = _cnt();
    msecs += _muldiv64(ticke - ticks, 1000, _clockfreq());  // ticks to milliseconds
    printf("Copied %d of %d bytes at %d kB/s\n", count, filesize,
        (_muldiv64(count, 1000, msecs) + 512) >> 10);

}



static void  checkfile( const char *filename )
{
    FILE  *fh;
    size_t  filesize, bufsize, count = 0;
    uint32_t  ticks, ticke, tickf, msecs = 0, onesecond, *data;
    int  passed = 1;

    if(!mounted)
        mountall();

    filesize = fgetsize(filename);
    printf("read back file length = %d\n", filesize);

    if(filesize / MAX_BUFFER_SIZE)  bufsize = MAX_BUFFER_SIZE;
    else  bufsize = filesize;

    if(data = __builtin_alloca(bufsize))    // auto-frees upon return
        printf("read back buffer addr = 0x%x, size = %d\n", data, bufsize);
    else {
        printf("malloc() failed!\n");
        exit(1);
    }
    memset(data, 0, bufsize);  // erase any echoes

    onesecond = _clockfreq();
    ticks = _cnt();
    tickf = ticks;

    errno = 0;
    fh = fopen(filename, "rb");
    if(!fh) {
        perror("fopen() for read back failed");
        exit(1);
    }

    do {
        if(!fread(data, bufsize, 1, fh))  exit(1);
        ticke = _cnt();
        while(ticke - tickf >= onesecond)  {
            tickf += onesecond;
            msecs += 1000;
        }
        if(bufsize == randcmp(data, bufsize))  count += bufsize;
        else {
            passed = 0;
            break;
        }
    } while(count < filesize);

    fclose(fh);
    ticke = _cnt();
/*    ticks = ticke - ticks;
    printf("Read back %d of %d bytes at %d kB/s\n", count, filesize,
        (_muldiv64(count, _clockfreq(), ticks) + 512) >> 10);
*/
    msecs += _muldiv64(ticke - tickf, 1000, _clockfreq());  // ticks to milliseconds
//    printf("ticks = %d, msecs = %d\n", ticks, msecs);
    printf("Read back %d of %d bytes at %d kB/s\n", count, filesize,
        (_muldiv64(count, 1000, msecs) + 512) >> 10);

    if( passed )  puts("Compare match.  :)");
    else  puts("Compare mismatch!");
}


//===================================================================================

static void  shutdown( void )
{
    printf("\nClean-up ...\n errno = %d: %s\n", errno, strerror(errno));

    umount("/sd1");
    umount("/sd2");

    _waitms(500);
    _clkset(1, 20_000);  // cool running
}



const char filepath1[] = "/sd1/copy1.bin";
const char filepath2[] = "/sd2/copy1.bin";


void  main( void )
{
    uint32_t  seed;
    int  i;

    printf("\n   clkfreq = %d   clkmode = 0x%x\n\n", _clockfreq(), _clockmode());
    atexit(shutdown);

    for(i = 0; i < 3; i++)
    {
        rmfile(filepath1);
        rmfile(filepath2);
        seed = _rnd();
        printf("data seed = 0x%08x\n", seed);
        xoro32state = seed;
        writefile(filepath1, 4_400_000);
        xoro32state = seed;
        checkfile(filepath1);
        copyfile(filepath1, filepath2);
        xoro32state = seed;
        checkfile(filepath2);
    }

    exit(0);
}
